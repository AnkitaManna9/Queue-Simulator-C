# Queue Simulator — FIFO Data Structure

A browser-based interactive project for modelling a single ticket counter and a single printer queue using First-In, First-Out (FIFO).

## Run locally
1. Download or clone this repository.
2. Open `index.html` in a modern browser.
3. Choose Ticket Counter or Printer Queue.
4. Set duration, arrival probability and service-time range.
5. Select **Run Simulation** or **Next Tick**.
6. Review the statistics, event log and transaction table.
7. Select **Download CSV Report** to export the records.

## Publish using GitHub Pages
1. Sign in to https://github.com.
2. Create a new **Public** repository, for example `queue-simulator`.
3. Upload `index.html` and `README.md` to the repository root.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch `main` and folder `/ (root)`, then click **Save**.
7. Wait for GitHub Pages to publish. The public URL will look like:
   `https://YOUR-USERNAME.github.io/queue-simulator/`
8. Open the URL in an incognito/private browser window to verify public access.

## Model notes
- The website uses JavaScript because GitHub Pages serves static files and does not run a Python backend.
- It implements the report's tick-based FIFO logic in the browser.
- Arrival probability is checked once per tick.
- Printer job page counts are converted to service ticks using 5 pages per tick.
- CSV export is generated in the visitor's browser; no database or server is required.
- This is a single-server, non-priority FIFO model.

## Files
- `index.html` — complete website, styling, simulation engine and CSV export.
- `README.md` — setup and GitHub Pages instructions.
